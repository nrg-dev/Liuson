package com.nrg.liusen.util;

import java.text.NumberFormat;
import java.util.Locale;


public class CommaFormat {
	
	public static final int interval=1000;
	public static final String suffixID="@nrg.com";
	public static NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);

}
