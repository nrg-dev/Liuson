
$(document).ready(function() {
	(function(){var d=window,e=document,f="text/javascript",g="text/css",h="stylesheet",k="script",l="link",m="head",n="complete",p="UTF-8",q=".";function r(b){var a=e.getElementsByTagName(m)[0];a||(a=e.body.parentNode.appendChild(e.createElement(m)));a.appendChild(b)}function _loadJs(b){var a=e.createElement(k);a.type=f;a.charset=p;a.src=b;r(a)}function _loadCss(b){var a=e.createElement(l);a.type=g;a.rel=h;a.charset=p;a.href=b;r(a)}function _isNS(b){b=b.split(q);for(var a=d,c=0;c<b.length;++c)if(!(a=a[b[c]]))return!1;return!0}function _setupNS(b){b=b.split(q);for(var a=d,c=0;c<b.length;++c)a=a[b[c]]||(a[b[c]]={});return a}
	d.addEventListener&&"undefined"==typeof e.readyState&&d.addEventListener("DOMContentLoaded",function(){e.readyState=n},!1);
	if (_isNS('google.translate.Element')){return}(function(){var c=_setupNS('google.translate._const');c._cl='en';c._cuc='googleTranslateElementInit';c._cac='';c._cam='';var h='translate.googleapis.com';var s=(true?'https':window.location.protocol=='https:'?'https':'http')+'://';var b=s+h;c._pah=h;c._pas=s;c._pbi=b+'/translate_static/img/te_bk.gif';c._pci=b+'/translate_static/img/te_ctrl3.gif';c._pli=b+'/translate_static/img/loading.gif';c._plla=h+'/translate_a/l';c._pmi=b+'/translate_static/img/mini_google.png';c._ps=b+'/translate_static/css/translateelement.css';c._puh='translate.google.com';_loadCss(c._ps);_loadJs(b+'/translate_static/js/element/main.js');})();})();
});







/*
$(document).ready(function() {
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
 $('#me1').hide();
 $('#me2').hide();
 $('#me3').hide();
 $('#me4').hide();
 $('#me5').hide();
 $('#me6').hide();
 $('#me7').hide();
 $('#me8').hide();
 $('#me9').hide();
 $('#me10').hide();
 $('#me11').hide();
 $('#me12').hide();
 $('#me13').hide();
 $('#me14').hide();
 $('#me15').hide();
 $('#me16').hide();
 $('#me17').hide();
 $('#me18').hide();
 $('#me19').hide();
 $('#me20').hide();
 $('#me21').hide();
 $('#me22').hide();
 $('#me23').hide();
 $('#me24').hide();
 $('#me25').hide();
 $('#me26').hide();
 $('#me27').hide();
 $('#me28').hide();
 $('#me29').hide();
 $('#me30').hide();
 $('#me31').hide();
 $('#me32').hide();
 $('#me33').hide();
 $('#me34').hide();
 $('#me35').hide();
 $('#me36').hide();
 $('#me37').hide();
 $('#me38').hide();
 $('#me39').hide();
 $('#me40').hide();
 $('#me42').hide();
 $('#me43').hide();
 $('#me41').hide();

$('#clickme1').click(function() {
          $('#me1').animate({
               height: 'toggle'
               }, 2000
          );
     });



$('#clickme2').click(function() {
          $('#me2').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme3').click(function() {
          $('#me3').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme4').click(function() {
          $('#me4').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme5').click(function() {
          $('#me5').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme6').click(function() {
          $('#me6').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme7').click(function() {
          $('#me7').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme8').click(function() {
          $('#me8').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme9').click(function() {
          $('#me9').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme10').click(function() {
          $('#me10').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme11').click(function() {
          $('#me11').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme12').click(function() {
          $('#me12').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme13').click(function() {
          $('#me13').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme14').click(function() {
          $('#me14').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme15').click(function() {
          $('#me15').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme16').click(function() {
          $('#me16').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme17').click(function() {
          $('#me17').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme18').click(function() {
          $('#me18').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme19').click(function() {
          $('#me19').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme20').click(function() {
          $('#me20').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme21').click(function() {
          $('#me21').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme22').click(function() {
          $('#me22').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme23').click(function() {
          $('#me23').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme24').click(function() {
          $('#me24').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme25').click(function() {
          $('#me25').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme26').click(function() {
          $('#me26').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme27').click(function() {
          $('#me27').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme28').click(function() {
          $('#me28').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme29').click(function() {
          $('#me29').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme30').click(function() {
          $('#me30').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme31').click(function() {
          $('#me31').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme32').click(function() {
          $('#me32').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme33').click(function() {
          $('#me33').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme34').click(function() {
          $('#me34').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme35').click(function() {
          $('#me35').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme37').click(function() {
          $('#me37').animate({
               height: 'toggle'
               }, 2000
          );
     });

$('#clickme38').click(function() {
          $('#me38').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme39').click(function() {
          $('#me39').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme40').click(function() {
          $('#me40').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme42').click(function() {
          $('#me42').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme43').click(function() {
          $('#me43').animate({
               height: 'toggle'
               }, 2000
          );
     });
$('#clickme41').click(function() {
          $('#me41').animate({
               height: 'toggle'
               }, 2000
          );
     });


 $("#change").mouseleave(function(){
    $("#change").css("background-color","#EFFBFB");
  });
$("#change").mouseenter(function(){
    $("#change").css("background-color","#E0F8F7");
  });

 $("#change1").mouseleave(function(){
    $("#change1").css("background-color"," #EFFBFB");
  });

$("#change1").mouseenter(function(){
    $("#change1").css("background-color","#E0F8F7");
  }); $("#change2").mouseleave(function(){
    $("#change2").css("background-color"," #EFFBFB");
  });
$("#change2").mouseenter(function(){
    $("#change2").css("background-color","#E0F8F7");
  }); $("#change3").mouseleave(function(){
    $("#change3").css("background-color"," #EFFBFB");
  });
$("#change3").mouseenter(function(){
    $("#change3").css("background-color","#E0F8F7");
  }); $("#change4").mouseleave(function(){
    $("#change4").css("background-color","#EFFBFB");
  });
$("#change4").mouseenter(function(){
    $("#change4").css("background-color","#E0F8F7");
  }); $("#change5").mouseleave(function(){
    $("#change5").css("background-color"," #EFFBFB");
  });
$("#change5").mouseenter(function(){
    $("#change5").css("background-color","#E0F8F7");
  });
 $("#change6").mouseleave(function(){
    $("#change6").css("background-color"," #EFFBFB");
  });
$("#change6").mouseenter(function(){
    $("#change6").css("background-color","#E0F8F7");
  });

 $("#change7").mouseleave(function(){
    $("#change7").css("background-color"," #EFFBFB");
  });
$("#change7").mouseenter(function(){
    $("#change7").css("background-color","#E0F8F7");
  });


});
*/